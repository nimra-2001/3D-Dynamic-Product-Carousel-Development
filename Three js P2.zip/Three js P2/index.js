// Wait for the window to load
window.addEventListener('load', () => {
    // Select all carousel elements
    var carousels = document.querySelectorAll('.carousel');
  
    // Loop through each carousel and initialize it
    for (var i = 0; i < carousels.length; i++) {
      carousel(carousels[i]);
    }
  });
  
  // Function to handle carousel setup and interactions
  function carousel(root) {
    // Get the figure and navigation elements from the carousel
    var figure = root.querySelector('figure'),
      nav = root.querySelector('nav'),
      images = figure.children,
      n = images.length,
      gap = root.dataset.gap || 0,
      bfc = 'bfc' in root.dataset,
      theta = 2 * Math.PI / n,
      currImage = 0;
  
    // Setup the carousel
    setupCarousel(n, parseFloat(getComputedStyle(images[0]).width));
    
    // Listen for window resize and adjust the carousel
    window.addEventListener('resize', () => { 
      setupCarousel(n, parseFloat(getComputedStyle(images[0]).width)); 
    });
    
    // Setup navigation buttons
    setupNavigation();
  
    // Function to setup the carousel
    function setupCarousel(n, s) {
      var apothem = s / (2 * Math.tan(Math.PI / n));
      
      // Set the transform origin for the figure
      figure.style.transformOrigin = `50% 50% ${-apothem}px`;
      
      // Set padding for each image
      for (var i = 0; i < n; i++) images[i].style.padding = `${gap}px`;
      
      // Setup transform for each image
      for (i = 1; i < n; i++) {
        images[i].style.transformOrigin = `50% 50% ${-apothem}px`;
        images[i].style.transform = `rotateY(${i * theta}rad)`;
      }
      
      // If backface culling is enabled, hide the backfaces
      if (bfc) {
        for (i = 0; i < n; i++) images[i].style.backfaceVisibility = 'hidden';
      }
      
      // Rotate the carousel to the current image
      rotateCarousel(currImage);
    }
  
    // Function to setup navigation buttons
    function setupNavigation() {
      // Add click event listener to navigation
      nav.addEventListener('click', onClick, true);
      
      // Function to handle button click
      function onClick(e) {
        e.stopPropagation();
        var t = e.target;
        
        // Check if the clicked element is a button
        if (t.tagName.toUpperCase() != 'BUTTON') return;
        
        // Update the current image index based on the button clicked
        if (t.classList.contains('next')) {
          currImage++;
        } else {
          currImage--;
        }
        
        // Rotate the carousel to the updated image
        rotateCarousel(currImage);
      }
    }
  
    // Function to rotate the carousel
    function rotateCarousel(imageIndex) {
      figure.style.transform = `rotateY(${imageIndex * -theta}rad)`;
    }
  }
  